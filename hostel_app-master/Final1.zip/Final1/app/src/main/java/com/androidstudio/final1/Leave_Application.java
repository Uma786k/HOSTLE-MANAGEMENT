package com.androidstudio.final1;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;

import android.os.Bundle;

public class Leave_Application extends AppCompatActivity {
    Button btn_click_new;
    Button btn_click_apply;
    EditText dateFrom;
    EditText dateTo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_application);

//        new button
        Button btn_click_new = (Button) findViewById(R.id.btn_new);
        btn_click_new.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Leave_Application.this, Leave_Application.class);
                startActivity(intent);
            }
        });

                //APPLY BUTTON
//        db pe update hona chahiye
        Button btn_click_apply = (Button) findViewById(R.id.btn_apply);
        btn_click_apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Leave_Application.this, Leave_Application.class);
                startActivity(intent);
            }
        });

//        Date and Time dialogue
                dateFrom = findViewById(R.id.dateFrom);
                dateTo = findViewById(R.id.dateTo);

                dateFrom.setInputType(InputType.TYPE_NULL);
                dateTo.setInputType(InputType.TYPE_NULL);

                dateFrom.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showDateAndTimeDialogFrom(dateFrom);
                    }
                });

                dateTo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showDateTimeDialogTo(dateTo);
                    }
                });


//For branch spinner
// Create an ArrayAdapter using the string array and a default spinner layout
// Specify the layout to use when the list of choices appears
// Apply the adapter to the spinner
                Spinner branch_spinner = (Spinner) findViewById(R.id.branch);
                ArrayAdapter<CharSequence> adapterForBranchSpinner = ArrayAdapter.createFromResource(this,
                        R.array.branch, android.R.layout.simple_spinner_item);
                adapterForBranchSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                branch_spinner.setAdapter(adapterForBranchSpinner);


//For year spinner
                Spinner year_spinner = (Spinner) findViewById(R.id.year);
                ArrayAdapter<CharSequence> adapterForYearSpinner = ArrayAdapter.createFromResource(this,
                        R.array.year, android.R.layout.simple_spinner_item);
                adapterForYearSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                year_spinner.setAdapter(adapterForYearSpinner);

//Date and time pickers below


            }


            private void showDateTimeDialogTo(final EditText dateTo) {
                final Calendar calendar = Calendar.getInstance();
                DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR,year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                        TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int hourDay, int minute) {
                                calendar.set(Calendar.HOUR_OF_DAY, hourDay);
                                calendar.set(Calendar.MINUTE, minute);

                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy-MM-dd HH:mm");

                                dateTo.setText(simpleDateFormat.format(calendar.getTime()));

                            }
                        };

                        new TimePickerDialog(Leave_Application.this, timeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show();
                    }
                };
                new DatePickerDialog(Leave_Application.this, dateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }

            private void showDateAndTimeDialogFrom(final EditText dateFrom) {
                final Calendar calendar = Calendar.getInstance();
                DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR,year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                        TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int hourDay, int minute) {
                                calendar.set(Calendar.HOUR_OF_DAY, hourDay);
                                calendar.set(Calendar.MINUTE, minute);

                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy-MM-dd HH:mm");

                                dateTo.setText(simpleDateFormat.format(calendar.getTime()));

                            }
                        };

                        new TimePickerDialog(Leave_Application.this, timeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show();
                    }
                };
                new DatePickerDialog(Leave_Application.this, dateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        }

